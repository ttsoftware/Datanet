

class Options:

    root_dir = "/var/www"